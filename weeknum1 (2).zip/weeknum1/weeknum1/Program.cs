﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using Microsoft.Win32; // Används för att läsa från registret

namespace WeekIconApp
{
    static class Program
    {
        [STAThread] // Attributet [STAThread] krävs för vissa Windows-funktioner
        static void Main()
        {
            Application.EnableVisualStyles();   // Starta applikationen med Windows visuella stilar
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new WeekIconContext()); // Kör applikationen med vårt egna context (WeekIconContext)
        }
    }

    public class WeekIconContext : ApplicationContext
    {
        private NotifyIcon trayIcon;    // Representerar ikonen i systemtray
        private Timer updateTimer;
        private int currentWeekCache = -1;  // Cache för aktuell vecka (bör vara -1 initialt för att säkerställa uppdatering vid start)

        public WeekIconContext()
        {
            ContextMenu trayMenu = new ContextMenu();   // Skapa en snabbmeny med ett "Exit"-alternativ.
            trayMenu.MenuItems.Add("Exit", OnExit);

            // Skapa och konfigurera tray-ikonen.
            trayIcon = new NotifyIcon
            {
                Icon = SystemIcons.Shield,  // Standardikon
                ContextMenu = trayMenu,
                Visible = true
            };

            updateTimer = new Timer { Interval = 60000 };
            updateTimer.Tick += UpdateTimer_Tick;
            updateTimer.Start();

            // Uppdatera ikonen direkt vid start.
            UpdateIcon();
        }

        private void UpdateTimer_Tick(object sender, EventArgs e)
        {
            UpdateIcon();
        }

        // Uppdaterar ikonen och tooltip baserat på aktuellt veckonummer.
        private void UpdateIcon()
        {
            int week = GetWeekNumber(DateTime.Now);
            if (week != currentWeekCache)
            {
                currentWeekCache = week;    // Spara den nya veckan i cachen
                if (trayIcon.Icon != null)
                {
                    trayIcon.Icon.Dispose();
                }
                trayIcon.Icon = CreateIcon(week);
            }
            trayIcon.Text = "Vecka " + week.ToString();
        }

        // Beräknar veckonumret för ett givet datum, ser på vart man är och kalenderregler samt första veckodagen
        private int GetWeekNumber(DateTime date)
        {
            CultureInfo ci = CultureInfo.CurrentCulture;
            return ci.Calendar.GetWeekOfYear(date,
                ci.DateTimeFormat.CalendarWeekRule,
                ci.DateTimeFormat.FirstDayOfWeek);
        }

        private void OnExit(object sender, EventArgs e)
        {
            trayIcon.Visible = false;
            Application.Exit();
        }

        // Kontrollerar om systemet är inställt på mörkt läge genom att läsa registret.
        private bool IsDarkModeEnabled()
        {
            try
            {
                // Öppna registret på sökvägen där systemets tema sparas
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
                {
                    if (key != null)
                    {
                        object registryValueObject = key.GetValue("SystemUsesLightTheme");
                        if (registryValueObject != null)
                        {
                            int registryValue = (int)registryValueObject;
                            // Om värdet är 0 => mörkt läge, om 1 => ljust läge.
                            return registryValue == 0;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Vid fel => ljust läge.
            }
            return false;
        }

        // Skapar en ikon med veckonumret, anpassad efter systemets tema.
        private Icon CreateIcon(int weekNumber)
        {
            int size = 32;
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                // Gör bakgrunden transparent.
                g.Clear(Color.Transparent);

                // Hämta systemets tema-status.
                bool isDarkMode = IsDarkModeEnabled();

                // Välj textfärg baserat på om är i mörkt eller ljust läge.
                Color textColor = isDarkMode ? Color.White : Color.Black;
                string text = weekNumber.ToString();

                // Rita ut veckonumret centrerat.
                using (Font font = new Font("Arial", 20, FontStyle.Bold))
                using (SolidBrush brush = new SolidBrush(textColor))
                {
                    SizeF textSize = g.MeasureString(text, font);
                    float x = (size - textSize.Width) / 2;
                    float y = (size - textSize.Height) / 2;
                    g.DrawString(text, font, brush, x, y);
                }
            }
            // Konvertera bitmapen till en ikon.
            return Icon.FromHandle(bmp.GetHicon());
        }
    }
}

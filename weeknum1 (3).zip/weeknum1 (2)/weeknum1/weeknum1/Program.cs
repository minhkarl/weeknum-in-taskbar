﻿using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using Microsoft.Win32; // Används för att läsa från registret

namespace WeekIconApp
{
    static class Program
    {
        [STAThread] // Attributet [STAThread] krävs för vissa Windows-funktioner
        static void Main()
        {
            Application.EnableVisualStyles();   // Starta applikationen med Windows visuella stilar
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new WeekIconContext()); // Kör applikationen med vårt egna context (WeekIconContext)
        }
    }

    public class WeekIconContext : ApplicationContext
    {
        private NotifyIcon trayIcon;    // Representerar ikonen i systemtray
        private Timer updateTimer;
        private int currentWeekCache = -1;  // Cache för aktuell vecka (bör vara -1 initialt för att säkerställa uppdatering vid start)

        public WeekIconContext()
        {
            // Skapa en snabbmeny med alternativet "Beräkna veckonummer" samt "Exit".
            ContextMenu trayMenu = new ContextMenu();
            trayMenu.MenuItems.Add("Beräkna veckonummer", ShowWeekCalculator);
            trayMenu.MenuItems.Add("Vecka till datum", ShowWeekToDate);
            trayMenu.MenuItems.Add("Exit", OnExit);
            trayMenu.MenuItems.Add("Automatisk Textinmatning", ShowTypingForm);


            // Skapa och konfigurera tray-ikonen.
            trayIcon = new NotifyIcon
            {
                Icon = SystemIcons.Shield,  // Standardikon
                ContextMenu = trayMenu,
                Visible = true
            };

            updateTimer = new Timer { Interval = 60000 };
            updateTimer.Tick += UpdateTimer_Tick;
            updateTimer.Start();

            // Uppdatera ikonen direkt vid start.
            UpdateIcon();
        }

        private void UpdateTimer_Tick(object sender, EventArgs e)
        {
            UpdateIcon();
        }
        private void ShowTypingForm(object sender, EventArgs e)
        {
            TypingForm typingForm = new TypingForm();
            typingForm.ShowDialog();
        }

        // Uppdaterar ikonen och tooltip baserat på aktuellt veckonummer.
        private void UpdateIcon()
        {
            int week = GetWeekNumber(DateTime.Now);
            if (week != currentWeekCache)
            {
                currentWeekCache = week;    // Spara den nya veckan i cachen
                if (trayIcon.Icon != null)
                {
                    trayIcon.Icon.Dispose();
                }
                trayIcon.Icon = CreateIcon(week);
            }
            trayIcon.Text = "Vecka " + week.ToString();
        }

        // Beräknar veckonumret för ett givet datum, ser på vart man är och kalenderregler samt första veckodagen
        private int GetWeekNumber(DateTime date)
        {
            CultureInfo ci = CultureInfo.CurrentCulture;
            return ci.Calendar.GetWeekOfYear(date,
                ci.DateTimeFormat.CalendarWeekRule,
                ci.DateTimeFormat.FirstDayOfWeek);
        }

        // Kontrollerar om systemet är inställt på mörkt läge genom att läsa registret.
        private bool IsDarkModeEnabled()
        {
            try
            {
                // Öppna registret på sökvägen där systemets tema sparas
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
                {
                    if (key != null)
                    {
                        object registryValueObject = key.GetValue("SystemUsesLightTheme");
                        if (registryValueObject != null)
                        {
                            int registryValue = (int)registryValueObject;
                            // Om värdet är 0 => mörkt läge, om 1 => ljust läge.
                            return registryValue == 0;
                        }
                    }
                }
            }
            catch (Exception)
            {
                // Vid fel => ljust läge.
            }
            return false;
        }

        // Skapar en ikon med veckonumret, anpassad efter systemets tema.
        private Icon CreateIcon(int weekNumber)
        {
            int size = 32;
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                // Gör bakgrunden transparent.
                g.Clear(Color.Transparent);

                // Hämta systemets tema-status.
                bool isDarkMode = IsDarkModeEnabled();

                // Välj textfärg baserat på om är i mörkt eller ljust läge.
                Color textColor = isDarkMode ? Color.White : Color.Black;
                string text = weekNumber.ToString();

                // Rita ut veckonumret centrerat.
                using (Font font = new Font("Arial", 22, FontStyle.Bold))
                using (SolidBrush brush = new SolidBrush(textColor))
                {
                    SizeF textSize = g.MeasureString(text, font);
                    float x = (size - textSize.Width) / 2;
                    float y = (size - textSize.Height) / 2;
                    g.DrawString(text, font, brush, x, y);
                }
            }
            // Konvertera bitmapen till en ikon.
            return Icon.FromHandle(bmp.GetHicon());
        }

        private void OnExit(object sender, EventArgs e)
        {
            trayIcon.Visible = false;
            Application.Exit();
        }

        // Öppnar en ny form där du kan välja ett datum och se veckonumret.
        private void ShowWeekCalculator(object sender, EventArgs e)
        {
            WeekCalculatorForm calculatorForm = new WeekCalculatorForm();
            calculatorForm.ShowDialog();
        }
        private void ShowWeekToDate(object sender, EventArgs e)
        {
            WeekToDateForm weekToDateForm = new WeekToDateForm();
            weekToDateForm.ShowDialog();
        }

    }

    public class TypingForm : Form
    {
        private TextBox textBox;
        private NumericUpDown delayInput;
        private NumericUpDown speedInput;
        private Label warningLabel;
        private CheckBox humanDelayCheckbox;
        private Button startButton;
        private Button stopButton;
        private Timer typingTimer = new Timer();
        private Timer delayTimer;
        private string textToType = "";
        private int currentIndex = 0;
        private readonly Random random = new Random();

        public TypingForm()
        {
            Text = "Automatisk textinmatning";
            Size = new Size(400, 360);
            StartPosition = FormStartPosition.CenterParent;
            TopMost = true;

            // Label och textbox för texten som ska skrivas
            var textLabel = new Label
            {
                Text = "Text att skriva:",
                Location = new Point(10, 10),
                Width = 300
            };
            textBox = new TextBox
            {
                Location = new Point(10, 30),
                Size = new Size(360, 80),
                Multiline = true,
                ScrollBars = ScrollBars.Vertical
            };

            // Delay-inställning
            var delayLabel = new Label
            {
                Text = "Fördröjning (sek):",
                Location = new Point(10, 120),
                Width = 150
            };
            delayInput = new NumericUpDown
            {
                Location = new Point(160, 118),
                Minimum = 0,
                Maximum = 60,
                Value = 3
            };

            // Hastighets-inställning
            var speedLabel = new Label
            {
                Text = "Skrivhastighet (ms per bokstav):",
                Location = new Point(10, 150),
                Width = 200
            };
            speedInput = new NumericUpDown
            {
                Location = new Point(220, 148),
                Minimum = 75,      
                Maximum = 1000,
                Value = 100,
                Increment = 1
            };

            // Varningslabel
            warningLabel = new Label
            {
                Text = "Ha inte under 100 ms, annars kan det bugga!",
                Location = new Point(10, 180),
                Width = 360,
                ForeColor = Color.OrangeRed
            };

            // Checkbox för humaniserad fördröjning
            humanDelayCheckbox = new CheckBox
            {
                Text = "Humaniserad fördröjning",
                Location = new Point(10, 210),
                Width = 200
            };

            // Start-knapp
            startButton = new Button
            {
                Text = "Starta inmatning",
                Location = new Point(10, 240),
                Width = 360
            };
            startButton.Click += StartButton_Click;

            // Stop-knapp
            stopButton = new Button
            {
                Text = "Stoppa inmatning",
                Location = new Point(10, 280),
                Width = 360
            };
            stopButton.Click += StopButton_Click;

            typingTimer.Tick += TypingTimer_Tick;

            Controls.AddRange(new Control[]
            {
            textLabel, textBox,
            delayLabel, delayInput,
            speedLabel, speedInput,
            warningLabel,
            humanDelayCheckbox,
            startButton,
            stopButton
            });
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            // Stoppa timers och återställ fönstret
            delayTimer?.Stop();
            typingTimer.Stop();
            TopMost = true;
            BringToFront();
        }

        private void StartButton_Click(object sender, EventArgs e)
        {
            // Hämta och normalisera texten
            textToType = textBox.Text
                .Replace("\r\n", "\n")
                .Replace("\r", "\n");
            currentIndex = 0;

            // Låt formuläret ligga kvar synligt, men släpp TopMost så att målfönstret kan ha fokus
            TopMost = false;

            // Starta delay-timer
            delayTimer = new Timer { Interval = (int)delayInput.Value * 1000 };
            delayTimer.Tick += (s, ev) =>
            {
                delayTimer.Stop();
                typingTimer.Interval = (int)speedInput.Value;
                typingTimer.Start();
            };
            delayTimer.Start();
        }

        private void TypingTimer_Tick(object sender, EventArgs e)
        {
            if (currentIndex < textToType.Length)
            {
                char ch = textToType[currentIndex];
                try
                {
                    if (ch == '\n')
                        SendKeys.SendWait("{ENTER}");
                    else
                        SendKeys.SendWait(ch.ToString());
                }
                catch { }
                finally
                {
                    currentIndex++;
                }

                // Lägg på slumpmässig extra fördröjning om markerat
                if (humanDelayCheckbox.Checked)
                    typingTimer.Interval += random.Next(1, 120);
            }
            else
            {
                typingTimer.Stop();
                // När klart, sätt tillbaka TopMost så du kan stoppa/formen blir synlig överst igen
                TopMost = true;
                BringToFront();
            }
        }
    }

    public class WeekToDateForm : Form
    {
        private TextBox weekInputBox;
        private Label resultLabel;
        private Button convertButton;

        public WeekToDateForm()
        {
            this.Text = "Veckonummer till Datum";
            this.Size = new Size(300, 200);
            this.StartPosition = FormStartPosition.CenterParent;

            Label instruction = new Label
            {
                Text = "Skriv ett veckonummer:",
                Location = new Point(20, 20),
                Width = 200
            };

            weekInputBox = new TextBox
            {
                Location = new Point(20, 50),
                Width = 100
            };

            convertButton = new Button
            {
                Text = "Visa första dagen",
                Location = new Point(20, 90),
                Width = 150
            };
            convertButton.Click += ConvertButton_Click;

            resultLabel = new Label
            {
                Text = "",
                Location = new Point(20, 130),
                Width = 250
            };

            this.Controls.Add(instruction);
            this.Controls.Add(weekInputBox);
            this.Controls.Add(convertButton);
            this.Controls.Add(resultLabel);
        }

        private void ConvertButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(weekInputBox.Text, out int week) && week >= 1 && week <= 53)
            {
                DateTime startDate = FirstDateOfISOWeek(DateTime.Now.Year, week);
                resultLabel.Text = $"Vecka {week} börjar: {startDate:dddd d MMMM}";
            }
            else
            {
                resultLabel.Text = "Ogiltigt veckonummer!";
            }
        }

        private DateTime FirstDateOfISOWeek(int year, int weekOfYear)
        {
            // ISO 8601: Vecka 1 är den vecka som innehåller den första torsdagen
            DateTime jan4 = new DateTime(year, 1, 4);
            // Hitta måndagen den veckan börjar
            int dayOfWeek = (int)jan4.DayOfWeek;
            if (dayOfWeek == 0) dayOfWeek = 7; // Gör söndag = 7

            DateTime firstWeekStart = jan4.AddDays(1 - dayOfWeek); // Går till måndag i vecka 1
            return firstWeekStart.AddDays((weekOfYear - 1) * 7);
        }

    }

    // En enkel form för att välja ett datum och få fram veckonumret.
    public class WeekCalculatorForm : Form
    {
        private DateTimePicker dateTimePicker;
        private Button calculateButton;
        private Label resultLabel;

        public WeekCalculatorForm()
        {
            this.Text = "Veckonummer Kalkylator";
            this.Size = new Size(350, 200);
            this.StartPosition = FormStartPosition.CenterScreen;

            // Skapa och konfigurera DateTimePicker
            dateTimePicker = new DateTimePicker
            {
                Location = new Point(20, 20),
                Width = 300
            };

            // Skapa och konfigurera knappen
            calculateButton = new Button
            {
                Text = "Beräkna veckonummer",
                Location = new Point(20, 60)
            };
            calculateButton.Click += CalculateButton_Click;

            // Skapa och konfigurera label för att visa resultatet
            resultLabel = new Label
            {
                Text = "Välj ett datum och tryck på knappen",
                Location = new Point(20, 100),
                Width = 300
            };

            // Lägg till kontrollerna i formen
            this.Controls.Add(dateTimePicker);
            this.Controls.Add(calculateButton);
            this.Controls.Add(resultLabel);
        }

        // Händelsehanterare för knappen som beräknar veckonumret.
        private void CalculateButton_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dateTimePicker.Value;
            int weekNumber = GetWeekNumber(selectedDate);
            resultLabel.Text = "Vecka " + weekNumber.ToString();
        }

        // Beräknar veckonumret med hjälp av aktuell kultur.
        private int GetWeekNumber(DateTime date)
        {
            CultureInfo ci = CultureInfo.CurrentCulture;
            return ci.Calendar.GetWeekOfYear(
                date,
                ci.DateTimeFormat.CalendarWeekRule,
                ci.DateTimeFormat.FirstDayOfWeek);
        }
    }
}

﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.Globalization;


namespace weeknum1
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            // Run the application with our custom context.
            Application.Run(new WeekTrayContext());
        }
    }
    public class WeekTrayContext : ApplicationContext
    {
        private NotifyIcon trayIcon;
        private Timer updateTimer;
        private int currentWeekCache = -1;

        public WeekTrayContext()
        {
            // Create a context menu with an "Exit" option.
            ContextMenu trayMenu = new ContextMenu();
            trayMenu.MenuItems.Add("Exit", OnExit);

            // Create and configure the tray icon.
            trayIcon = new NotifyIcon
            {
                Icon = SystemIcons.Shield,  // You can change this to your custom icon.
                ContextMenu = trayMenu,
                Visible = true,
                Text = "Week " + GetWeekNumber(DateTime.Now).ToString()
            };

            // Set up a timer to update the tray icon tooltip every minute.
            updateTimer = new Timer { Interval = 60000 }; // 60 seconds.
            updateTimer.Tick += UpdateTimer_Tick;
            updateTimer.Start();
        }

        private void UpdateTimer_Tick(object sender, EventArgs e)
        {
            UpdateTrayIcon();
        }


        private int GetWeekNumber(DateTime date)
        {
            CultureInfo ci = CultureInfo.CurrentCulture;
            return ci.Calendar.GetWeekOfYear(date, ci.DateTimeFormat.CalendarWeekRule, ci.DateTimeFormat.FirstDayOfWeek);
        }

        private void OnExit(object sender, EventArgs e)
        {
            trayIcon.Visible = false;
            Application.Exit();
        }
        private void UpdateTrayIcon()
        {
            int week = GetWeekNumber(DateTime.Now);
            // Only update if the week has changed.
            if (week != currentWeekCache)
            {
                // Update the cached week.
                currentWeekCache = week;

                // Generate a new icon with the week number.
                Icon newIcon = GenerateIcon(week);
                // Dispose the previous icon to avoid resource leaks.
                if (trayIcon.Icon != null)
                {
                    trayIcon.Icon.Dispose();
                }
                trayIcon.Icon = newIcon;
            }

            // Always update the tooltip.
            trayIcon.Text = "Week " + week.ToString();
        }

        private Icon GenerateIcon(int weekNumber)
        {
            int size = 32; // Icon size in pixels
            Bitmap bmp = new Bitmap(size, size);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                // Clear the bitmap to fully transparent.
                g.Clear(Color.Transparent);

                // Draw the week number in white, centered.
                string text = weekNumber.ToString();
                using (Font font = new Font("Arial", 20, FontStyle.Bold))
                using (SolidBrush textBrush = new SolidBrush(Color.White))
                {
                    SizeF textSize = g.MeasureString(text, font);
                    float x = (size - textSize.Width) / 2;
                    float y = (size - textSize.Height) / 2;
                    g.DrawString(text, font, textBrush, x, y);
                }
            }
            // Convert the bitmap to an Icon. Note: Icon.FromHandle creates an icon that should eventually be disposed.
            return Icon.FromHandle(bmp.GetHicon());
        }

    }
}

